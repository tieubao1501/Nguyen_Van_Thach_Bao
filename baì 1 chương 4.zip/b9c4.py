ds=input('danh sach: ').split()
