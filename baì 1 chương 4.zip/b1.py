n1=int(input("enter n1 vualue"))
n2=int(input("enter n2 vualue"))
if n1>n2:
  print(' n1 big')
else:
  print(' n2 big')

