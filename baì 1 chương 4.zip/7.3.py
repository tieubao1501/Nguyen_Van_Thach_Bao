def checkvalue(n):
    if n%2==0:
        print('đay la so chan')
    else:
        print('dsy la so le')
checkvalue(8)
