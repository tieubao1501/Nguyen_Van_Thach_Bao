s1='bao'
s2='vejsgrti'
s3='igjesgiuhtrd'
print(' tu dai nhat : ',max(s1,s2,s3, key=len))
