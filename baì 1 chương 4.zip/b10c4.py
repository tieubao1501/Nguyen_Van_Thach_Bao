ds=input('danh sach: ').split()
x=ds[0:-1]
for c in x:
    print(c)
