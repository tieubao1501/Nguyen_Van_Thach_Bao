a='ughfrg'
b=a[4]
c=b in a
print(b)
