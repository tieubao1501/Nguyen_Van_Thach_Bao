a='hello'
def say_hello(a):
    a='hello'
    print(a) 
print(a)

