ds=input('danh sach: ').split()
print(ds)
for so in ds:
    print(so)
