x = 1
y = "2"
z = 3

sum = 0
for i in (x,y,z):
      if isinstance(i, int):
          sum += i
print (sum)
