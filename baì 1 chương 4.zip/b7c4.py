ds='bao123 vrg'
import re
ds1=re.sub("[0-9]","",ds)
print(ds1)
