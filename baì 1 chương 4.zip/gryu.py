print "Hello World"
[::-1]
