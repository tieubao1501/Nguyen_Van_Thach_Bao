def sum(a,b):
    print('sum=' + str(a+b))
sum(4,5)
sum(3,7)

