n=int(input("nhap n"))
if n>0:
   print ("duong")
else:
   print("am")

