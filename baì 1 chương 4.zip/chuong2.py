print(" hello,wrd")
print(' vũ đình thi, 19575202160033, kĩ thuạt điều khiển và tdh')
