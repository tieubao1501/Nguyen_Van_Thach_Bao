ds=input('danh sach: ').split()
print('vi tri cua chuoi to la', ds.index('to'))
