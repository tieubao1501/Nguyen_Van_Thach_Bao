ds=input('danh sach: ').split()
ds.sort()
for ch in ds:
    print(ch)
