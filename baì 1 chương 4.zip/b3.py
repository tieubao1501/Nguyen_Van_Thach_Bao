n=int(input("nhap n"))
if n % 2 ==0:
    print('chan')
else:
    print('le')
