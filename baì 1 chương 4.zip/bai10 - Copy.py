a=' hello'
b=a.split()
print (b)
c="".join(b)
print(c)
