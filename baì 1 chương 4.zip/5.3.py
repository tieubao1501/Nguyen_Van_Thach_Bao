a='hello guy'
def say():
    global a
    a='vinhuni'
    print(a)
say()
print(a)
