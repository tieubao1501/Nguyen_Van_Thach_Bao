def add(a,b):
    sum=a + b
    hieu=a-b
    return sum
    return hieu
x=int(input())
y=int(input())
tong= add(x,y)
g=add(x,y)
print(tong)
print(g)
