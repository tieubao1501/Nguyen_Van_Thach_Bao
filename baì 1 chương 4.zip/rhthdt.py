r=int(input())
p=r*2*3.14
s=r*r*3.14
print(p)
print(s)
