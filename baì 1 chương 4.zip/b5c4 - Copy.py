ds=input('danh sach: ').split()
print(ds[::-1])
