import math
math.pi
r=float(input('nhap r:')
if r<0 :
        print('khong hop le')
def tinh(r):
    p=2*3.14*r
    print(p)
    s=3.14*(r*r)
    print(s)
tinh(r)
print(tinh(r))
