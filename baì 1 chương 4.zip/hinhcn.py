def cv_dt(rong, dai):
    chuvi = (rong + dai) * 2
    dientich = rong * dai
    print("Chu vi =", chuvi)
    print("Dien tich =", dientich)
rong=input()
dai=input()
