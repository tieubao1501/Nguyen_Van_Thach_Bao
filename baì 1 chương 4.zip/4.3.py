a='hello guy'
def say(a):
    a='vinhuni'
    print(a)
say(a)
print(a)
