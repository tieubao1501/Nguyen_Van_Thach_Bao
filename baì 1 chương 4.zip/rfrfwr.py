class Point:
     def init (self, x = 0, y = 0):
         self.x = x+1
         self.y = y+1
p1 = Point()
print(p1.x, p1.y)
