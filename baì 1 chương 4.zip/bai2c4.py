s=input('nhap chuoi:')
print(s.replace('',''))
